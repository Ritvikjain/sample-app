import { ACTION_TYPES } from '../constants/actionTypes';

const setBottomTabs = (data) => ({
  type: ACTION_TYPES.APP.BOTTOM_TABS,
  data
});

const setUserProfile = (data) => ({
  type: ACTION_TYPES.APP.USER_PROFILE,
  data
});

const setReceiverData = (data) => ({
  type: ACTION_TYPES.APP.RECEIVER_DATA,
  data
});

const setPaymentDetails = (data) => ({
  type: ACTION_TYPES.APP.PAYMENT_DETAILS,
  data
});

const setSelectedPlan = (data) => ({
  type: ACTION_TYPES.APP.SELECTED_PLAN,
  data
});

export {
  setBottomTabs,
  setUserProfile,
  setReceiverData,
  setPaymentDetails,
  setSelectedPlan,
};
