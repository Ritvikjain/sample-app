import { APICallStatus, PgOrderStatus } from "../../constants";
import { AuthService } from "../../service/AuthService"
import { TopupService } from "../../service/TopupService";
import { receiverDataSelector } from "../selectors/app";
import store from "../store";

export const fetchReceiverProfile = async ({receiverPhoneNumber}) => {
  try {
    const response = await AuthService.fetchReceiverProfile({
      phoneNumber: receiverPhoneNumber,
    });
    return {
      status: APICallStatus.SUCCESS,
      fullName: response?.data?.fullName,
      email: response?.data?.email,
      isExistingUser: response?.data?.isExistingUser,
    }
  } catch (error) {
    return {
      status: APICallStatus.ERROR,
    }
  }
}

export const fetchAllRechargePlans = async () => {
  try {
    const response = await TopupService.fetchAllTopupPlans({});
    console.log(response, 'xyzxyz');
    return {
      status: APICallStatus.SUCCESS,
      planDetails: response?.data?.planDetails
    };
  } catch (error) {
    return {
      status: APICallStatus.ERROR,
    };
  }
}

export const initiateWalletTopup = async ({planId}) => {
  try {
    const receiverData = receiverDataSelector(store.getState());
    const response = await TopupService.initiateWalletTopup({
      planId: planId,
      phoneNumber: receiverData?.phoneNumber,
    });
    console.log(response,' xyzxyz')
    return {
      status: APICallStatus.SUCCESS,
      ...response?.data,
    };
  } catch (error) {
    return {
      status: APICallStatus.ERROR,
    };
  }
}

export const initiateMilindWalletTopup = async ({planId, phoneNumber, senderName, senderPhoneNumber}) => {
  try {
    const response = await TopupService.initiateWalletTopup({
      planId: planId,
      phoneNumber: phoneNumber,
      senderName,
      senderPhoneNumber,
    });
    console.log(response,' xyzxyz')
    return {
      status: APICallStatus.SUCCESS,
      ...response?.data,
    };
  } catch (error) {
    console.log(error)
    return {
      status: APICallStatus.ERROR,
    };
  }
}


export const handlePaymentPollingLogic = async (paymentIntentId, callback) => {
  try {
    const timeout = 90000;
    let currentTime = 0;
    let responseSuccess = false;
    let lastApiResult = null;
    let currentTimerValue = 2000;
    const timer = setInterval(async () => {
      // currentTimerValue = 2000;
      let result = await TopupService.paymentStatusPolling({
        payementIntentId: paymentIntentId
      });
      console.log(result,'api response')
      lastApiResult = result;
      currentTime += currentTimerValue;
      if (result?.data?.status === PgOrderStatus.SUCCESS || result?.data?.status === PgOrderStatus.CANCELLED || result?.data?.status === PgOrderStatus.ERROR || currentTime >= timeout) {
        responseSuccess = true;
        callback(result?.data);
        clearInterval(timer);
      }
    }, currentTimerValue);

    setTimeout(() => {
      if (!responseSuccess) {
        clearInterval(timer);
        callback(lastApiResult?.data);
      }
    }, timeout + 2000);
  } catch (error) {
    
  }
}