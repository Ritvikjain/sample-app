import { AppType } from '../../constants';
import { ACTION_TYPES } from '../constants/actionTypes';

const initialState = {
  userProfile: {},
  receiverData: null,
  paymentDetails: null,
  selectedPlan: null,
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case ACTION_TYPES.APP.USER_PROFILE:
      return {
        ...state,
        userProfile: action.data
      }
    case ACTION_TYPES.APP.RECEIVER_DATA:
      return {
        ...state,
        receiverData: action.data
      }
    case ACTION_TYPES.APP.PAYMENT_DETAILS:
      return {
        ...state,
        paymentDetails: action.data
      }
    case ACTION_TYPES.APP.SELECTED_PLAN:
      return {
        ...state,
        selectedPlan: action.data
      }
    default:
      return state;
  }
};

export default reducer;
