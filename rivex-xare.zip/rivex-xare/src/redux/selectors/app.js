import { createSelector } from "reselect";

export const appSliceSelector = (state) => state.app || {};

export const bottomTabsSelector = createSelector(appSliceSelector, appState => appState && appState.bottomTabs || {});

export const receiverDataSelector = createSelector(appSliceSelector, appState => appState && appState.receiverData || null);

export const paymentDetailsSelector = createSelector(appSliceSelector, appState => appState && appState.paymentDetails || null);

export const selectedPlanSelector = createSelector(appSliceSelector, appState => appState && appState.selectedPlan || null);

export const userProfileSelector = createSelector(appSliceSelector, appState => appState && appState.userProfile || null);