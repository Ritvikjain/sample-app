import { createSelector } from "reselect";

export const authSliceSelector = (state) => state.auth || {};

export const accessTokenSelector = createSelector(authSliceSelector, authState => authState && authState?.accessToken || null);

export const refreshTokenSelector = createSelector(authSliceSelector, authState => authState && authState?.refreshToken || null);

export const isUserLoggedInSelector = createSelector(authSliceSelector, authState => authState && authState?.isUserLoggedIn || null);