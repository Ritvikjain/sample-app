import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAOYx7w0tr1j28dHE2J6F9hmNwF8mjnDic",
  authDomain: "rive-47667.firebaseapp.com",
  projectId: "rive-47667",
  storageBucket: "rive-47667.appspot.com",
  messagingSenderId: "606927370877",
  appId: "1:606927370877:web:f9be41dbd4e4f7cb5a8f14",
  measurementId: "G-RYGGX6KPES"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export default app;
