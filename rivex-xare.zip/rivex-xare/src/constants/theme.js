export const theme = {
  COLOR: {
    ThemePrimary: '#1981f9',
    Grey: '#898989',
    Grey100: '#767676',
    Grey200: '#EEEEEE',
    WhitePrimary: '#ffffff',
    LightGrey: '#CAD1DA',
    LightGrey100: '#F5F8F9',
    SuccessGreen: '#16BF69',
    Red: '#FF656F',
    YellowOrange: '#ffb200',
    YellowOrangeDark: '#FF9300',
  },
  FONT: {
    PrimaryRegular: 'PrimaryRegular',
    PrimarySemiBold: 'PrimarySemiBold',
    PrimaryBold: 'PrimaryBold',
    PrimaryLight: 'PrimaryLight',
    PrimaryRegularItalic: 'PrimaryRegularItalic',
    PrimarySemiBoldItalic: 'PrimarySemiBoldItalic',
    PrimaryLight: 'PrimaryLight',
    PrimaryBoldItalic: 'PrimaryBoldItalic',
  }
}