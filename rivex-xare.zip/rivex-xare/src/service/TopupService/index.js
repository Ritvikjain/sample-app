import { APICallStatus } from "../../constants";
import { Config } from "../../constants/config";
import { setUserProfile } from "../../redux/actions/app";
import { setAccessToken, setIsUserLoggedIn, setRefreshToken } from "../../redux/actions/auth";
import store from "../../redux/store";
import { saveTokens } from "../../redux/thunks/auth.thunk";
import { ApiService } from "../ApiService"

export const fetchAllTopupPlans = async (params) => {
  return await ApiService.postApi(Config.apis.topup.fetchAllTopupPlans, params);
}

export const initiateWalletTopup = (params) => {
  return ApiService.postApi(Config.apis.topup.walletPaymentInitiate, params);
}

export const paymentStatusPolling = (params) => {
  return ApiService.postApi(Config.apis.topup.paymentCheckStatus, params);
}

export const TopupService = {
  fetchAllTopupPlans,
  initiateWalletTopup,
  paymentStatusPolling,
}