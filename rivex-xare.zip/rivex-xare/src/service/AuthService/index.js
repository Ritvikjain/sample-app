import { APICallStatus } from "../../constants";
import { Config } from "../../constants/config";
import { setUserProfile } from "../../redux/actions/app";
import { setAccessToken, setIsUserLoggedIn, setRefreshToken } from "../../redux/actions/auth";
import store from "../../redux/store";
import { saveTokens } from "../../redux/thunks/auth.thunk";
import { ApiService } from "../ApiService"

export const isValidToken = async () => {
  try {
    const query = new URLSearchParams(window.location.href);
    const response = await ApiService.postTokenApi('/v1/auth/isTokenValid', {});
  } catch (error) {
    
  }
}

export const phoneSignin = async (phoneNumber) => {
  try {
    const response = await ApiService.postApi(Config.apis.auth.phoneSignin, {
      phoneNumber: `${phoneNumber}`,
    });
    return {
      status: APICallStatus.SUCCESS,
      verificationId: response?.data?.verificationId,
    };
  } catch (error) {
    console.log(error);
    return {
      status: APICallStatus.ERROR,
    };
  }
}

export const phoneSigninEmail = async (email) => {
  try {
    const response = await ApiService.postApi(Config.apis.auth.phoneSignin, {
      email: email,
      mode: 'email',
    });
    return {
      status: APICallStatus.SUCCESS,
      verificationId: response?.data?.verificationId,
    };
  } catch (error) {
    console.log(error);
    return {
      status: APICallStatus.ERROR,
    };
  }
}

export const verifyPhoneOtp = async (otpValue, verificationId) => {
  try {
    const dispatch = store.dispatch;
    const response = await ApiService.postApi(Config.apis.auth.verifyOtp, {
      verificationId: verificationId,
      otp: otpValue,
      mode: 'email',
    });
    const accessToken = response?.data?.tokens.accessToken;
    const refreshToken = response?.data?.tokens.refreshToken;
    const userProfileData = response?.data?.user;
    saveTokens({
      accessToken,
      refreshToken,
    });
    dispatch(setUserProfile(userProfileData));
    dispatch(setIsUserLoggedIn(true));
    return {
      status: APICallStatus.SUCCESS,
    };
  } catch (error) {
    console.log(error, 'xyzxyz')
    return {
      status: APICallStatus.ERROR,
    };
  }
}

export const checkTokenValidity = async () => {
  try {
    const response = await ApiService.postApi(Config.apis.auth.tokenCheck, {});

    return {
      status: APICallStatus.SUCCESS,
    }
  } catch (error) {
    return {
      status: APICallStatus.ERROR
    }
  }
}

export const fetchUserProfile = async () => {
  return await ApiService.postApi(Config.apis.auth.fetchUserProfile, {});
}

export const fetchReceiverProfile = async (params) => {
  return await ApiService.postApi(Config.apis.auth.fetchReceiverProfile, params);
}

export const AuthService = {
  isValidToken,
  phoneSignin,
  verifyPhoneOtp,
  checkTokenValidity,
  phoneSigninEmail,
  fetchUserProfile,
  fetchReceiverProfile,
}