import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import App from "./App";
import { Provider } from "react-redux";
import store from "./redux/store";
import { loadStripe } from "@stripe/stripe-js";
import { Elements } from "@stripe/react-stripe-js";
import './index.css';

const stripePromise = loadStripe(process?.env?.REACT_APP_STRIPE_KEY);


ReactDOM.render(
  <React.StrictMode>
    <Elements stripe={stripePromise}>
      <Provider store={store}>
        <Router>
          <App />
        </Router>
      </Provider>
    </Elements>
  </React.StrictMode>,
  document.getElementById("root")
);
