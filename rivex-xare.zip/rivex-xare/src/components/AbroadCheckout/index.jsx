import { faCheckCircle, faExclamationCircle, faInfoCircle, faShield, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useRef, useState } from 'react'
import { Card } from 'react-bootstrap';
import { formatCurrency } from '../../constants/codeUtils';
import { theme } from '../../constants/theme';
import FooterCtaContainer from '../../elements/FooterCtaContainer';
import { styles } from './styles'
import {loadStripe} from '@stripe/stripe-js';
import {
  CardElement,
  Elements,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js';
import layout from '../../constants/layout';
import { useSelector } from 'react-redux';
import { paymentDetailsSelector, selectedPlanSelector } from '../../redux/selectors/app';
import { handlePaymentPollingLogic } from '../../redux/thunks/topup.thunk';
import { PgOrderStatus } from '../../constants';
import CustomToast from '../../elements/CustomToast';
import StripeLogo from '../../assets/images/stripeLogo.png';
import { useNavigate } from 'react-router-dom';


const TxnStatus = {
  NOT_STARTED: 'NOT_STARTED',
  PROCESSING: 'PROCESSING',
  SUCCESS: 'SUCCESS',
  PENDING: 'PENDING',
  FAILURE: 'FAILURE',
}

export default function AbroadCheckout() {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [error, setError] = useState({
    isError: false,
  });
  const [statusModalData, setStatusModalData] = useState({
    planDescription: '',
    title: '',
    description: '',
    showStatus: false,
    status: PgOrderStatus.PROCESSING,
  });
  const navigate = useNavigate();
  const paymentDetails = useSelector(paymentDetailsSelector);
  const selectedPlan = useSelector(selectedPlanSelector);
  const [toastData, setToastData] = useState({visible: false, message: '', type: null});
  const [transactionStatus, setTransactionStatus] = useState(TxnStatus.NOT_STARTED);

  const paymentStatusCallback = async (data) => {
    if(data?.status === PgOrderStatus.SUCCESS) {
      setTransactionStatus(TxnStatus.SUCCESS);
    } else if(data?.status === PgOrderStatus.PROCESSING) {
      setTransactionStatus(TxnStatus.PENDING);
    } else {
      setTransactionStatus(TxnStatus.FAILURE);
    }
  }

  if(!paymentDetails?.paymentIntent) { 
    navigate('/abroad-payment')
  }

  const handleSubmit = async (event) => {
    try {
      event.preventDefault();

      if (!stripe || !elements) {
        return;
      }
      setIsLoading(true);
      const response = await stripe.confirmCardPayment(paymentDetails?.paymentIntent, {
        payment_method: {
          card: elements.getElement(CardElement)
        },
      });
      if(response?.error) {
        setIsLoading(false);
        setError({
          isError: true,
          message: response?.error?.message,
        });
      } else {
        handlePaymentPollingLogic(paymentDetails?.paymentIntentId, paymentStatusCallback);
      }
    } catch (error) {
    }
  }

  const getStatusContent = () => {
    switch (transactionStatus) {
      case TxnStatus.SUCCESS:
        return {
          icon: faCheckCircle,
          iconColor: theme.COLOR.SuccessGreen,
          title: 'Payment Successful'
        };
      case TxnStatus.PENDING:
        return {
          icon: faExclamationCircle,
          iconColor: theme.COLOR.YellowOrangeDark,
          title: 'Payment Processing'
        };
      case TxnStatus.FAILURE:
      default:
        return {
          icon: faTimesCircle,
          iconColor: theme.COLOR.Red,
          title: 'Payment Failed'
        };
    }
  }

  if (transactionStatus === TxnStatus.SUCCESS || transactionStatus === TxnStatus.FAILURE || transactionStatus === TxnStatus.PENDING) {
    return(<>
      <div className="d-flex flex-column justify-content-center align-items-center pt-5"  style={styles.container}>
        <div className="d-flex flex-column justify-content-center align-items-center mt-5 pt-5 px-4">
        <FontAwesomeIcon icon={getStatusContent().icon} color={getStatusContent().iconColor} size={'7x'}/>
        <p className='mt-5' style={styles.upiStatusText}>{getStatusContent().title}</p>
        </div>
      </div>
      <FooterCtaContainer 
      />
    </>)
  } else {
  return (
    <>
    <div className="d-flex flex-column"  style={styles.container}>
      {/* <p style={styles.title}>Checkout</p> */}
      <div className='d-flex flex-column justify-content-center mt-3' style={error?.isError ? styles.cardInputErrorContainer : isFocused ? styles.cardInputActiveContainer : styles.cardInputContainer}>
        <CardElement 
          options={{
            iconStyle: 'solid',
            style: {
              base: {
                fontSize: layout.window.toNormH(24),
              }
            },
          }}
          onChange={(cardDetails) => {
            console.log(cardDetails?.error)
            if(cardDetails?.error) {
              setError({
                isError: true,
                message: cardDetails?.error?.message
              })
            } else {
              setError({
                isError: false
              })
            }
          }}
          onFocus={() => {
            setIsFocused(true);
          }}
          onBlur={() => {
            setIsFocused(false);
          }}
        />
      </div>
      {error?.isError ? <p style={styles.errorText}>{error?.message}</p> : null}
    </div>
    <FooterCtaContainer 
      aboveDescriptionText={() => {
        return <div className='d-flex justify-content-center mb-2 align-items-center'>
          <p className='mb-0' style={styles.secureText}>100% safe & secure</p>
          <FontAwesomeIcon className='mx-1' icon={faShield} color={theme.COLOR.SuccessGreen}/>
        </div>
      }}
      primaryAttributes={{
        title: 'Proceed',
        onClick: handleSubmit,
        isLoading: isLoading,
      }}
      showStripePoweredLogo
    />
    </>
  )
  }
}
