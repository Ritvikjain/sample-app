import React, { useEffect, useState } from 'react'
import { BallTriangle } from 'react-loader-spinner'
import { useNavigate } from 'react-router-dom';
import { APICallStatus } from '../../constants';
import layout from '../../constants/layout';
import store from '../../redux/store';
import { fetchUserProfile, saveTokens } from '../../redux/thunks/auth.thunk';
import { styles } from './styles';

export default function AuthVerification() {
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState('Something went wrong');
  const navigate = useNavigate();

  const loadSenderProfile = async () => {
    try {
      const response = await fetchUserProfile({});
      if(response?.status === APICallStatus.SUCCESS) {
        navigate('/verifyReceiver');
      } else {
        setIsLoading(false);
        setErrorMessage(response?.message || 'Something went wrong');
      }
    } catch (error) {
      
    }
  }

  useEffect(() => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    const token = urlParams.get('token');
    if(token && token?.length>0) {
      saveTokens({
        accessToken: urlParams.get('token')
      });
      loadSenderProfile();
    } else {
      setIsLoading(false);
      setErrorMessage('Not authorized to access the portal.');
    }
  })

  return (
    <>
      {isLoading ? <div style={styles.loaderContainer}>
        <BallTriangle
          height={120}
          width={layout.window.toNormW(100)}
          radius={layout.window.toNormW(6)}
          color="#1981f9"
          ariaLabel="ball-triangle-loading"
          wrapperClass={{}}
          wrapperStyle=""
          visible={true}
        />
      </div> : <div style={styles.container}>
        <p style={styles.errorText}>{errorMessage}</p>
      </div>}
    </>
  )
}
