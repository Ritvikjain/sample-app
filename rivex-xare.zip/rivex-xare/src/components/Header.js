import userEvent from "@testing-library/user-event";
import { Button, Image } from "react-bootstrap";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import NavDropdown from "react-bootstrap/NavDropdown";
import { useNavigate } from "react-router-dom";
import { useUserAuth } from "../context/UserAuthContext";
import RiveNameLogo from "../assets/images/rivexLogo.png";
import { useSelector } from "react-redux";
import { logout } from "../redux/thunks/auth.thunk";
import { layer } from "@fortawesome/fontawesome-svg-core";
import layout from "../constants/layout";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faArrowCircleLeft, faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { theme } from "../constants/theme";
import { getPlatform } from "../constants/codeUtils";

const styles = {
  title: {
    fontSize: layout.window.toNormH(24),
    fontFamily: theme.FONT.PrimarySemiBold
  },
  headerNavBar: {
    position: 'fixed',
    padding: layout.window.toNormW(22),
    paddingTop: getPlatform() === 'iOS' ? layout.window.toNormH(62) : layout.window.toNormH(22),
    paddingBottom: layout.window.toNormH(16),
    backgroundColor: 'white',
    alignItems: 'center',
    width: '100%',
    boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px',
    zIndex: 10,
  },
  headerNavBarEmptyContainer: {
    height: getPlatform() === 'iOS' ? layout.window.toNormH(116) : layout.window.toNormH(86), // add 30 when app fixed
    width: '100%',
  },
  backButtonContainer: {
    width: layout.window.toNormW(40),
    height: layout.window.toNormW(40),
    // backgroundColor: 'red',
    alignSelf: 'center',
    justifyContent: 'flex-start',
    alignItems: 'center',
  }
}

function Header({
  title,
  showBackButton,
}) {
  const navigate = useNavigate();
 
  return (
    <>
      <div className="d-flex" style={styles.headerNavBar}>
        {showBackButton ? <span className="d-flex" style={styles.backButtonContainer} onClick={() => navigate(-1)}>
          <FontAwesomeIcon icon={faArrowLeft} size={layout.window.toNormH(26)}/>
        </span> : null}
        {<p id={`nav-title-${title?.toLowerCase().split(' ').join('-')}`} className="mb-0" style={styles?.title}>{title}</p>}
      </div>
      <div className="d-flex" style={styles.headerNavBarEmptyContainer} />
    </>
  );
}

export default Header;
