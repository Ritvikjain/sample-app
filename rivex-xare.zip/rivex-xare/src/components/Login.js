import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Alert } from "react-bootstrap";
import { Button } from "react-bootstrap";
import './Login.css';
import { isValidToken } from "../service/AuthService";
import { checkUserLoggedIn } from "../redux/thunks/auth.thunk";
import Loader from "../elements/loader";
import { BallTriangle } from "react-loader-spinner";
const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const onLoad = async () => {
    try {
      setIsLoading(true);
      const isLoggedIn = await checkUserLoggedIn();
      if (isLoggedIn) {
        navigate("/home");
      }
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    onLoad();
  }, [])
  

  return (
    <>
      <div className="p-4 box loginCenterForm">
        <h3 className="mb-2 text-center">Rive Admin Login</h3>
        <span style={{fontSize:"14px", textAlign:'center'}}>Login in with your registered email</span>
        {error && <Alert variant="danger">{error}</Alert>}
        <Link to="/emailsignup">
          <div className="d-grid gap-2 mt-4">
            <Button variant="success" type="Submit">
              Sign in with Email
            </Button>
          </div>
        </Link>
      </div>
      {isLoading ? <div style={{position: 'absolute', width: '100%', height: '100%', backgroundColor: 'rgba(39, 50, 58, 0.9)', display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
        <BallTriangle
          height={120}
          width={100}
          radius={6}
          color="#1981f9"
          ariaLabel="ball-triangle-loading"
          wrapperClass={{}}
          wrapperStyle=""
          visible={true}
        />
      </div> : null}
    </>
  );
};

export default Login;
