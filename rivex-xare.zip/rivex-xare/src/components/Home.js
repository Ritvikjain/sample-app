import React, { useEffect } from "react";
import { Button, Card, Col, Container, Row } from "react-bootstrap";
import { useNavigate } from "react-router";
import Header from "./Header";
import axios from 'axios';
const Home = () => {
  const navigate = useNavigate();
  const getHeaders = () => {
    return {
        headers: {
            'Content-Type': 'application/json',
            // 'Authorization': `Bearer ${user.accessToken}`
        }
    };
}
  useEffect(() => {
    // async function callApi(){
    //   const body = {
    //     metaData:{
    //       userId: null
    //     },
    //     data:{
    //       uid: user?.uid,
    //       phoneNumber: user?.phoneNumber
    //     }
    //   }
    //   const response = await axios.post(`${process.env.REACT_APP_BACKEND_DOMAIN}/v1/user/isAdminUser`, body, getHeaders(user?.accessToken));
    // if(response?.data){
    //   console.log(response?.data);
    //   let isAdmin = response?.data?.isAdmin;
    //   if(!isAdmin){
    //     logOut();
    //   }
    // }
    // }
    // if(user?.accessToken){
    //   callApi();
    // }
  
    return () => {
    };
  }, []);
  return (
    <>
      <Container style={{ paddingTop: "4%" }}>
        <Row xs={1} md={4} className="g-4">
          <Col>
            <Card>
              <Card.Header><b>Card Verifications</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  New cards added to the rive platform for credit card verifications.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/cardVerificationDetails')}>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Manage Notification</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Manage all notifications i.e. push notifications, sms and email here.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/manageNotifications')}>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Manage spending limits</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Manage (increase/decrease) users spending limit here.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/manageLimits')} disabled>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Manage reversals</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Manage transaction reversals (hard/soft) here.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/manageReversals')} disabled>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Activate / Deactivate user</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  See user data and activate / deactivate user.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/activateDeactivateUser')} disabled>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Tickets Management</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Update user's raised help tickets status here.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/ticketManagement')} disabled>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>FAQs Management</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  View, edit and manage all the FAQs here.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/faqManagement')} disabled>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Remove user card</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Check and unlink user's credit card and allow to add another card.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/removeUserCard')} disabled>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Bill repayment Polling</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Manually trigger polling for failure or timeout polling for pending txn.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/billRepaymentPolling')}>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Bill Generation</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Manually generate user bill.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/billGeneration')}>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

          <Col>
            <Card>
              <Card.Header><b>Settle user's bill</b></Card.Header>
              <Card.Body>
                <Card.Text>
                  Manually settles user's bill and capture transactions.
                </Card.Text>
                <Button variant="primary" onClick={()=>navigate('/billManagement')}>Enter</Button>
              </Card.Body>
            </Card>
          </Col>

        </Row>
      </Container>
    </>
  );
};

export default Home;
