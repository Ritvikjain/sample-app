import { faCheckCircle, faExclamationCircle, faInfoCircle, faTag, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState } from 'react'
import { Button, Card } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { BottomSheet } from 'react-spring-bottom-sheet';
import { APICallStatus, PgOrderStatus } from '../../constants';
import { formatCurrency } from '../../constants/codeUtils';
import layout from '../../constants/layout';
import { theme } from '../../constants/theme';
import Dropdown from '../../elements/Dropdown';
import FooterCtaContainer from '../../elements/FooterCtaContainer';
import Input from '../../elements/Input/input'
import LoaderView from '../../elements/LoaderView';
import PhoneInput from '../../elements/PhoneInput';
import { setPaymentDetails, setSelectedPlan } from '../../redux/actions/app';
import { fetchAllRechargePlans, fetchReceiverProfile, handlePaymentPollingLogic, initiateWalletTopup } from '../../redux/thunks/topup.thunk';
import ReceiverDetailsModal from '../modals/ReceiverDetailsModal';
import { styles } from './styles';
import QRCode from "react-qr-code";
import { ApiService } from '../../service/ApiService';
import { RotatingLines } from 'react-loader-spinner';

const TxnStatus = {
  NOT_STARTED: 'NOT_STARTED',
  PROCESSING: 'PROCESSING',
  SUCCESS: 'SUCCESS',
  PENDING: 'PENDING',
  FAILURE: 'FAILURE',
}

export default function IndiaPayment() {

  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [upiId, setUpiId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [transactionStatus, setTransactionStatus] = useState(TxnStatus.NOT_STARTED);

  const paymentStatusCallback = async (data) => {
    if(data?.status === PgOrderStatus.SUCCESS) {
      setTransactionStatus(TxnStatus.SUCCESS);
    } else if(data?.status === PgOrderStatus.PROCESSING) {
      setTransactionStatus(TxnStatus.PENDING);
    } else {
      setTransactionStatus(TxnStatus.FAILURE);
    }
  }

  const submitVpa = async () => {
    try {
      setIsLoading(true);
      const response = await ApiService.postApi('/v1/payments/initiateOpenCheckoutTemp', {
        vpa: upiId,
        senderPhoneNumber: phoneNumber,
        senderName: name,
      });
      if(response?.data?.status === APICallStatus.SUCCESS) {
        setTransactionStatus(TxnStatus.PROCESSING);
        handlePaymentPollingLogic(response?.data?.payementIntentId, paymentStatusCallback);
      }
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
    }
  }

  const getStatusContent = () => {
    switch (transactionStatus) {
      case TxnStatus.SUCCESS:
        return {
          icon: faCheckCircle,
          iconColor: theme.COLOR.SuccessGreen,
          title: 'Payment Successful'
        };
      case TxnStatus.PENDING:
        return {
          icon: faExclamationCircle,
          iconColor: theme.COLOR.YellowOrangeDark,
          title: 'Payment Processing'
        };
      case TxnStatus.FAILURE:
      default:
        return {
          icon: faTimesCircle,
          iconColor: theme.COLOR.Red,
          title: 'Payment Failed'
        };
    }
  }

  if (transactionStatus === TxnStatus.PROCESSING) {
    return(<>
      <div className="d-flex flex-column justify-content-center align-items-center pt-5"  style={styles.container}>
        <div className="d-flex flex-column justify-content-center align-items-center mt-5 pt-5 px-4">
        <RotatingLines
          strokeColor={theme.COLOR.Grey}
          strokeWidth={layout.window.toNormW(5)}
          animationDuration="0.75"
          width={layout.window.toNormW(80)}
          visible={true}
        />
        <p className='mt-5' style={styles.upiLoadingText}>Please open your UPI app and approve the payment request</p>
        <p className='mt-2' style={{...styles.upiLoadingText, color: theme.COLOR.Grey}}>Please do not refresh or go back</p>
        </div>
      </div>
      <FooterCtaContainer 
      />
    </>)
  } else if (transactionStatus === TxnStatus.SUCCESS || transactionStatus === TxnStatus.FAILURE || transactionStatus === TxnStatus.PENDING) {
    return(<>
      <div className="d-flex flex-column justify-content-center align-items-center pt-5"  style={styles.container}>
        <div className="d-flex flex-column justify-content-center align-items-center mt-5 pt-5 px-4">
        <FontAwesomeIcon icon={getStatusContent().icon} color={getStatusContent().iconColor} size={'7x'}/>
        <p className='mt-5' style={styles.upiStatusText}>{getStatusContent().title}</p>
        </div>
      </div>
      <FooterCtaContainer 
      />
    </>)
  } else {
    return (
      <>
      <div className="d-flex flex-column"  style={styles.container}>
        <p style={styles.title}>{`Payable amount`} - ₹ {`4,170`}</p>
        <div className='mt-2'>
          <Input label={'Enter Name'} value={name} onChange={setName} inputContainerStyles={{marginTop: layout.window.toNormH(12)}}/>
          <Input label={'Enter Phone Number'} value={phoneNumber} onChange={setPhoneNumber} inputContainerStyles={{marginTop: layout.window.toNormH(12)}}/>
          <Input label={'Enter VPA / UPI ID'} value={upiId} onChange={setUpiId} inputContainerStyles={{marginTop: layout.window.toNormH(12)}}/>
          {/* <Button className='d-flex mt-3' style={styles.submitVpaCta} onClick={submitVpa} disabled={isLoading}>
            {isLoading ? <RotatingLines
                strokeColor="white"
                strokeWidth={layout.window.toNormW(5)}
                animationDuration="0.75"
                width={layout.window.toNormW(22)}
                visible={true}
              /> : <p className='m-0'>Send request</p>}
          </Button> */}
        </div>
      </div>
      <FooterCtaContainer
        primaryAttributes={{
          title: 'Send request',
          onClick: submitVpa,
          isLoading: isLoading,
          isDisabled: !(name?.length > 0 && phoneNumber?.length > 5 && upiId?.length > 3)
        }} 
      />
      </>
    )
  }
}
