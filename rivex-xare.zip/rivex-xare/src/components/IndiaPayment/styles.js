import layout from "../../constants/layout";
import { theme } from "../../constants/theme";

export const styles = {
  container: {
    padding: layout.window.toNormW(22),
    paddingBottom: layout.window.toNormH(140),
  },
  title: {
    fontSize: layout.window.toNormH(20),
    fontFamily: theme.FONT.PrimarySemiBold,
    // textAlign: 'center'
  },
  scanTitle: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    marginTop: layout.window.toNormH(12),
    textAlign: 'center'
  },
  submitVpaCta: {
    flex: 1,
    width: '100%',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center'
  },
  upiLoadingText: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    marginTop: layout.window.toNormH(12),
    textAlign: 'center'
  },
  upiStatusText: {
    fontSize: layout.window.toNormH(20),
    fontFamily: theme.FONT.PrimarySemiBold,
    marginTop: layout.window.toNormH(12),
    textAlign: 'center'
  }
}