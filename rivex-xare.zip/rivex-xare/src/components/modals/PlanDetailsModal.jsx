import React from 'react'

export default function PlanDetailsModal() {
  return (
    <div>planDetails</div>
  )
}
