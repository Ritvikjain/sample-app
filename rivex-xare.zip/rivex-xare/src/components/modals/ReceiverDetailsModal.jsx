import { faCheckCircle, faExclamationTriangle } from '@fortawesome/free-solid-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import React from 'react'
import { Button, Modal } from 'react-bootstrap'
import layout from '../../constants/layout'
import { theme } from '../../constants/theme'

const styles = {
  detailsTitle: {
    fontSize: layout.window.toNormH(16),
  },
  detailsData: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold
  },
  centerDetailsData: {
    fontSize: layout.window.toNormH(16),
    textAlign: 'center'
  },
  successCta: {
    backgroundColor: theme.COLOR.SuccessGreen,
    flex: 1
  },
  primaryCta: {
    backgroundColor: theme.COLOR.ThemePrimary,
    flex: 1
  },
  title: {
    fontSize: layout.window.toNormH(20),
  }
}

export default function ReceiverDetailsModal({
  visible,
  onClose,
  onProceed,
  receiverData,
}) {
  return (
    <Modal className="mx-auto" show={visible} onHide={onClose} centered style={{padding: layout.window.toNormW(22)}}>
      {!receiverData?.isExistingUser ? <Modal.Body>
        <div className='d-flex justify-content-center mb-3' style={{alignItems: 'center'}}>
          <Modal.Title style={styles.title}>{!receiverData?.isExistingUser ? `Receiver not found` : `Receiver's details fetched`}</Modal.Title>
          {!receiverData?.isExistingUser ? <FontAwesomeIcon icon={faExclamationTriangle} color={theme.COLOR.Red} style={{fontSize: layout.window.toNormH(20), marginLeft: layout.window.toNormW(12)}}/> : <FontAwesomeIcon icon={faCheckCircle} color={theme.COLOR.SuccessGreen} style={{fontSize: layout.window.toNormH(20), marginLeft: layout.window.toNormW(12)}}/>}
        </div>
        <p className='m-0' style={styles.centerDetailsData}>By clicking on Proceed, you confirm the receiver details and the same will be updated in our records</p>
        <div className='d-flex flex-row justify-content-center mt-4'>
          <Button className='mx-2' variant="secondary" onClick={onClose} style={{flex: 1}}>
            Close
          </Button>
          <Button className='mx-2' variant="success" style={!receiverData?.isExistingUser ? styles.primaryCta : styles.successCta} onClick={onProceed}>
            Proceed
          </Button>
        </div>
      </Modal.Body> : <Modal.Body>
        <div className='d-flex justify-content-center mb-3' style={{alignItems: 'center'}}>
          <Modal.Title style={styles.title}>{!receiverData?.isExistingUser ? `Receiver not found` : `Receiver's details fetched`}</Modal.Title>
          {!receiverData?.isExistingUser ? <FontAwesomeIcon icon={faExclamationTriangle} color={theme.COLOR.Red} style={{fontSize: layout.window.toNormH(20), marginLeft: layout.window.toNormW(12)}}/> : <FontAwesomeIcon icon={faCheckCircle} color={theme.COLOR.SuccessGreen} style={{fontSize: layout.window.toNormH(20), marginLeft: layout.window.toNormW(12)}}/>}
        </div>
        <div className='d-flex justify-content-between'>
          <p className='m-0' style={styles.detailsData}>Name</p>
          <p className='m-0' style={styles.detailsData}>{receiverData?.fullName}</p>
        </div>
        <div className='d-flex justify-content-between'>
          <p className='m-0' style={styles.detailsData}>Email</p>
          <p className='m-0' style={styles.detailsData}>{receiverData?.email}</p>
        </div>
        <div className='d-flex flex-row justify-content-center mt-4'>
          <Button className='mx-2' variant="secondary" onClick={onClose} style={{flex: 1}}>
            Close
          </Button>
          <Button className='mx-2' variant="success" style={!receiverData?.isExistingUser ? styles.primaryCta : styles.successCta} onClick={onProceed}>
            Proceed
          </Button>
        </div>
        
      </Modal.Body>}
    </Modal>
  )
}
