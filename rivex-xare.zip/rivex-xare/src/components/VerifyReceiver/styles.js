import layout from "../../constants/layout";
import { theme } from "../../constants/theme";

export const styles = {
  container: {
    padding: layout.window.toNormW(22),
  },
  title: {
    fontSize: layout.window.toNormH(24),
  },
  formContainer: {

  },
  horizontalLine: {
    width: '100%',
    height: layout.window.toNormH(2),
    backgroundColor: theme.COLOR.Grey
  },
  orText: {
    fontSize: layout.window.toNormH(16),
  },
  noteText: {
    fontSize: layout.window.toNormH(14),
    fontFamily: theme.FONT.PrimaryRegular,
    color: theme.COLOR.Grey
  }
}