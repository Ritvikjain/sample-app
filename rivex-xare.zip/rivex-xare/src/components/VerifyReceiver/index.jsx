import React, { useEffect, useState } from 'react'
import { Alert, Button } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { theme } from '../../constants/theme';
import Dropdown from '../../elements/Dropdown';
import FooterCtaContainer from '../../elements/FooterCtaContainer';
import Input from '../../elements/Input/input'
import PhoneInput from '../../elements/PhoneInput';
import { setReceiverData } from '../../redux/actions/app';
import { fetchReceiverProfile } from '../../redux/thunks/topup.thunk';
import ReceiverDetailsModal from '../modals/ReceiverDetailsModal';
import { styles } from './styles'
import { countryCodes } from './utils';

export default function VerifyReceiver() {

  const [phoneNumber, setPhoneNumber] = useState('');
  const [countryCode, setCountryCode] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showReceiverDetails, setShowReceiverDetails] = useState(false);
  const [receiverData, setReceiverDataTemp] = useState(null);
  const [loadInitialData, setLoadInitialData] = useState(true);
  const [supported, setSupported] = useState(null);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const loadContacts = async () => {
    try {
      const props = ["name", "tel",];
      const opts = { multiple: true };
      if(navigator?.contacts) {
        const contacts = await navigator?.contacts?.select(props, opts);
      } else {
        alert('Feature not supported');
      }
    } catch (error) {
      alert('Feature not supported' + error);
    }
  }

  // useEffect(() => {
  //   if(loadInitialData) {
  //     const supported = ('contacts' in navigator && 'ContactsManager' in window);
  //     console.log(supported, 'xyzxyz supported');
  //     setSupported(supported ? "supported" : "not supported");
  //     loadContacts();
  //     setLoadInitialData(false);
  //   }
  // }, []);

  const handleSubmit = async () => {
    setIsLoading(true);
    const response = await fetchReceiverProfile({
      receiverPhoneNumber: `${countryCode?.dial_code}${phoneNumber}`
    });
    setReceiverDataTemp({
      fullName: response?.fullName,
      email: response?.email,
      phoneNumber: `${countryCode?.dial_code}${phoneNumber}`,
      isExistingUser: response?.isExistingUser,
    });
    setShowReceiverDetails(true);
    setIsLoading(false);
  }

  const handleProceed = async () => {
    setShowReceiverDetails(false);
    dispatch(setReceiverData(receiverData));
    navigate('/choosePlan');
  }

  return (
    <>
    <div className="d-flex flex-column"  style={styles.container}>
      <div className='mt-3' style={styles.formContainer}>
        <div className='mb-3'>
          <PhoneInput 
            label={`Receiver's contact number`}
            value={phoneNumber}
            onChange={setPhoneNumber}
            selectedCountryCode={countryCode}
            onChangeCountryCode={setCountryCode}
          />
          <p className='mt-3 mb-1' style={styles.noteText}>The contact details added above will also be used for communication purposes.</p>
          {/* <p>{supported}</p> */}
        </div>
      </div>
    </div>
    <FooterCtaContainer 
      primaryAttributes={{
        title: 'Submit',
        onClick: handleSubmit,
        isLoading: isLoading,
      }}
    />
    <ReceiverDetailsModal 
      visible={showReceiverDetails}
      receiverData={receiverData}
      onClose={() => {
        setShowReceiverDetails(false);
      }}
      onProceed={handleProceed}
    />
    </>
  )
}
