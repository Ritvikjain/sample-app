import React from 'react'
import { theme } from '../../constants/theme';
import Lottie from 'react-lottie-player'
import FailLottie from '../../assets/lotties/failLottie.json';
import SuccessLottie from '../../assets/lotties/successLottie.json';
import layout from '../../constants/layout';
import { formatCurrency, getFormattedDate } from '../../constants/codeUtils';
import { PgOrderStatus } from '../../constants';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { paymentDetailsSelector, selectedPlanSelector } from '../../redux/selectors/app';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShare, faShareNodes, faShareSquare } from '@fortawesome/free-solid-svg-icons';

const styles = {
  failContainer: {
    position: 'fixed',
    width: '100%',
    height: '100vh',
    backgroundColor: theme.COLOR.Red,
    top: 0,
    alignItems: 'center',
    paddingLeft: layout.window.toNormW(12),
    paddingRight: layout.window.toNormW(12),
    textAlign: 'center',
    zIndex:100,
  },
  successContainer: {
    position: 'fixed',
    width: '100%',
    height: '100vh',
    backgroundColor: theme.COLOR.SuccessGreen,
    top: 0,
    alignItems: 'center',
    paddingLeft: layout.window.toNormW(12),
    paddingRight: layout.window.toNormW(12),
    textAlign: 'center',
    zIndex:100,
  },
  planData: {
    fontSize: layout.window.toNormH(26),
    color: theme.COLOR.WhitePrimary
  },
  planStatusTitle: {
    fontSize: layout.window.toNormH(24),
    color: theme.COLOR.WhitePrimary
  },
  planStatusSubtitle: {
    fontSize: layout.window.toNormH(16),
    color: theme.COLOR.WhitePrimary
  },
  bottomCta: {
    // position: 'absolute',
    // bottom: layout.window.toNormH(140),
    paddingLeft: layout.window.toNormW(22),
    paddingRight: layout.window.toNormW(22),
    borderRadius: layout.window.toNormW(22),
    borderWidth: layout.window.toNormW(2),
    borderColor: theme.COLOR.WhitePrimary,
    borderStyle: 'solid',
    marginTop: layout.window.toNormH(100),
  },
  bottomCtaText: {
    fontSize: layout.window.toNormH(20),
    color: theme.COLOR.WhitePrimary
  },
  shareContainer: {
    borderWidth: layout.window.toNormW(2),
    borderColor: theme.COLOR.Grey200,
    borderStyle: 'dashed',
    borderRadius: layout.window.toNormW(12),
  },
  shareIconContainer: {
    marginLeft: layout.window.toNormW(12),
    color: theme.COLOR.Grey200
  },
  shareTitle: {
    fontSize: layout.window.toNormH(16),
    color: theme.COLOR.Grey200
  },
  shareCode: {
    fontSize: layout.window.toNormH(24),
    color: theme.COLOR.Grey200
  },
};

export default function PaymentStatusView ({
  data,
}) {
  const navigate = useNavigate();
  const paymentDetails = useSelector(paymentDetailsSelector);
  const selectedPlan = useSelector(selectedPlanSelector);

  const handleShareClick = () => {
    // if (navigator.share) {
      navigator.share({
        title: `Time to Celebrate 🥳\n\nI've toped up with *INR ${selectedPlan?.packAmountInr}*. Please follow the steps to add the money to your Shared Amount  -\n\n1️⃣ Check for the pending activations in Receive Money section.\n2️⃣ Tap on Activate top up.\n3️⃣ Enter the code below to activate the top up\n\n                 *${paymentDetails.receiverOtp}*\n     Valid till - ${getFormattedDate(paymentDetails.expiryTime, 'dd month yyyy')}\n\nIn 3 simple steps you can add money to your Shared Amount & can spend at millions of QR codes in India.\n\nTo know more, check 👉 https://links.rive.money/9dCPk`,
      }).then(() => {
          console.log('Thanks for sharing!');
      }).catch(err => {
          console.log("Error while using Web share API:");
          console.log(err);
      });
    // } else {

    //     // Alerts user if API not available 
    //     alert("Unable to share the code.");
    // }
  }
  return (
    <div className="d-flex flex-column justify-content-center" style={data?.status === PgOrderStatus?.SUCCESS ? styles.successContainer : styles.failContainer}>
      <Lottie
        loop
        animationData={data?.status === PgOrderStatus?.SUCCESS ? SuccessLottie : FailLottie}
        play
        style={{ width: layout.window.toNormW(150), height: layout.window.toNormW(150), marginTop: -layout.window.toNormH(42) }}
      />

      <p className='mt-5' style={styles.planData}>{data?.planDescription}</p>

      <p className='mb-0' style={styles.planStatusTitle}>{data?.title}</p>
      <p className='mt-2' style={styles.planStatusSubtitle}>{data?.description}</p>

      {data?.status === PgOrderStatus.SUCCESS ? <div className='d-flex py-2 px-3 mt-4' style={styles.shareContainer} onClick={handleShareClick}>
        <div>
          <p className='m-0' style={styles.shareTitle}>Receiver's activation code</p>
          <p className='m-0' style={styles.shareCode}>{paymentDetails?.receiverOtp}</p>
        </div>
        <div className='d-flex flex-column justify-content-center' style={styles.shareIconContainer}>
          <FontAwesomeIcon icon={faShareNodes}/>
        </div>
      </div> : null}

      <div className='py-1' style={styles.bottomCta} onClick={() => navigate('/verifyReceiver')}>
        <p className='m-0' style={styles.bottomCtaText}>Done</p>
      </div>
    </div>
  )
}
