import { faInfoCircle, faShield } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useRef, useState } from 'react'
import { Card } from 'react-bootstrap';
import { formatCurrency } from '../../constants/codeUtils';
import { theme } from '../../constants/theme';
import FooterCtaContainer from '../../elements/FooterCtaContainer';
import { styles } from './styles'
import {loadStripe} from '@stripe/stripe-js';
import {
  CardElement,
  Elements,
  useStripe,
  useElements,
} from '@stripe/react-stripe-js';
import layout from '../../constants/layout';
import { useSelector } from 'react-redux';
import { paymentDetailsSelector, selectedPlanSelector } from '../../redux/selectors/app';
import { handlePaymentPollingLogic } from '../../redux/thunks/topup.thunk';
import { PgOrderStatus } from '../../constants';
import PaymentStatusView from './PaymentStatusView';
import CustomToast from '../../elements/CustomToast';
import StripeLogo from '../../assets/images/stripeLogo.png';

export default function Checkout() {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [error, setError] = useState({
    isError: false,
  });
  const [statusModalData, setStatusModalData] = useState({
    planDescription: '',
    title: '',
    description: '',
    showStatus: false,
    status: PgOrderStatus.PROCESSING,
  });
  const paymentDetails = useSelector(paymentDetailsSelector);
  const selectedPlan = useSelector(selectedPlanSelector);
  const [toastData, setToastData] = useState({visible: false, message: '', type: null});

  const paymentStatusCallback = async (data) => {
    console.log(data, selectedPlan, 'xyzxyz status callback');
    setIsLoading(false);
    try {
      if(data?.status === PgOrderStatus.SUCCESS) {
        setStatusModalData({
          planDescription: `${selectedPlan?.name} - ₹ ${formatCurrency(selectedPlan?.packAmountInr)}`,
          title: 'Wallet topup successful',
          description: `₹ ${formatCurrency(selectedPlan?.packAmountInr)} added to wallet and now available to spend.`,
          showStatus: true,
          status: PgOrderStatus.SUCCESS,
        });
      } else if(data?.status === PgOrderStatus.PROCESSING) {
        setStatusModalData({
          planDescription: `${selectedPlan?.name} - ₹ ${formatCurrency(selectedPlan?.packAmountInr)}`,
          title: 'Wallet topup processing',
          description: `₹ ${formatCurrency(selectedPlan?.packAmountInr)} topup to wallet is currently processing we will update you soon.`,
          showStatus: true,
          status: PgOrderStatus.PROCESSING,
        });
      } else {
        setStatusModalData({
          planDescription: `${selectedPlan?.name} - ₹ ${formatCurrency(selectedPlan?.packAmountInr)}`,
          title: 'Wallet topup failed',
          description: `₹ ${formatCurrency(selectedPlan?.packAmountInr)} topup to wallet failed. Please try again.`,
          showStatus: true,
          status: PgOrderStatus.ERROR,
        });
      }
    } catch (error) {
      
    }
  }

  const handleSubmit = async (event) => {
    try {
      event.preventDefault();

      if (!stripe || !elements) {
        return;
      }
      setIsLoading(true);
      const response = await stripe.confirmCardPayment(paymentDetails?.paymentIntent, {
        payment_method: {
          card: elements.getElement(CardElement)
        },
      });
      if(response?.error) {
        setIsLoading(false);
        setToastData({
          visible: true,
          message: response?.error?.message,
          type: 'error',
        });
        setError({
          isError: true,
          message: response?.error?.message,
        });
      } else {
        handlePaymentPollingLogic(paymentDetails?.paymentIntentId, paymentStatusCallback);
      }
    } catch (error) {
    }
  }

  return (
    <>
    <div className="d-flex flex-column"  style={styles.container}>
      {/* <p style={styles.title}>Checkout</p> */}
      <div className='d-flex flex-column justify-content-center mt-3' style={error?.isError ? styles.cardInputErrorContainer : isFocused ? styles.cardInputActiveContainer : styles.cardInputContainer}>
        <CardElement 
          options={{
            iconStyle: 'solid',
            style: {
              base: {
                fontSize: layout.window.toNormH(24),
              }
            },
          }}
          onChange={(cardDetails) => {
            console.log(cardDetails?.error)
            if(cardDetails?.error) {
              setError({
                isError: true,
                message: cardDetails?.error?.message
              })
            } else {
              setError({
                isError: false
              })
            }
          }}
          onFocus={() => {
            setIsFocused(true);
          }}
          onBlur={() => {
            setIsFocused(false);
          }}
        />
      </div>
      {error?.isError ? <p style={styles.errorText}>{error?.message}</p> : null}
    </div>
    <FooterCtaContainer 
      aboveDescriptionText={() => {
        return <div className='d-flex justify-content-center mb-2 align-items-center'>
          <p className='mb-0' style={styles.secureText}>100% safe & secure</p>
          <FontAwesomeIcon className='mx-1' icon={faShield} color={theme.COLOR.SuccessGreen}/>
        </div>
      }}
      primaryAttributes={{
        title: 'Proceed',
        onClick: handleSubmit,
        isLoading: isLoading,
      }}
      showStripePoweredLogo
    />
    {statusModalData?.showStatus ? <PaymentStatusView
      data={statusModalData}
    /> : null}
    </>
  )
}
