import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Form, Alert, FloatingLabel } from "react-bootstrap";
import { Button } from "react-bootstrap";
import "react-phone-number-input/style.css";
import PhoneInput from "react-phone-number-input";
import { AuthService, isValidToken } from "../service/AuthService";
import { APICallStatus } from "../constants";

const EmailSignUp = () => {
  const [error, setError] = useState("");
  const [number, setNumber] = useState("");
  const [email, setEmail] = useState("");
  const [flag, setFlag] = useState(false);
  const [otp, setOtp] = useState("");
  const [result, setResult] = useState("");
  const navigate = useNavigate();

  const getOtp = async (e) => {
    e.preventDefault();
    console.log(email);
    setError("");
    if (email === "" || email === undefined)
      return setError("Please enter a valid email!");
    try {
      const adminEmails = ["ritvikjain2@gmail.com", "guru@xare.co", "pankaj.mishra2902@gmail.com"];
      if(!adminEmails?.includes(email)) {
        return setError("You are not authorized to access the portal");
      }
      const response = await AuthService.phoneSigninEmail(email);
      setResult(response);
      if(response?.status === APICallStatus.SUCCESS) {
        setFlag(true);
      }
    } catch (err) {
      console.log(error, '123')
      setError(err.message);
    }
  };

  const verifyOtp = async (e) => {
    e.preventDefault();
    setError("");
    if (otp === "" || otp === null) return;
    try {
      const response = await AuthService.verifyPhoneOtp(otp, result?.verificationId);
      if(response?.status === APICallStatus.SUCCESS)
        navigate("/home");
    } catch (err) {
      console.log(error)
      setError(err.message);
    }
  };

  return (
    <>
      <div className="p-4 loginCenterForm">
      {/* <h3 className="mb-3 text-center">Rive Admin Login</h3> */}
        {/* <Form onSubmit={getOtp} style={{ display: !flag ? "block" : "none", marginTop:"20px" }}>
          <Form.Group className="mb-3" controlId="formBasicEmail">
            <PhoneInput
              defaultCountry="IN"
              value={number}
              onChange={setNumber}
              placeholder="Enter Phone Number"
            />
            <div id="recaptcha-container"></div>
          </Form.Group>
          <div className="button-right">
            <Link to="/">
              <Button variant="secondary">Cancel</Button>
            </Link>
            &nbsp;
            <Button type="submit" variant="primary">
              Send Otp
            </Button>
          </div>
        </Form> */}
        <div style={{textAlign: 'left', display: flag ? "none" : "block"}}>
          <span style={{fontSize:"14px"}}>Please enter your registered email</span>
          {error && <Alert variant="danger">{error}</Alert>}
          <FloatingLabel
            controlId="floatingInput"
            label="Email"
            className="my-3"
          >
            <Form.Control type="text" value={email} placeholder="email here" onChange={(e) => setEmail(e?.target?.value)}/>
          </FloatingLabel>

          <div className="button-right">
            <Link to="/">
              <Button variant="secondary">Cancel</Button>
            </Link>
            &nbsp;
            <Button type="submit" variant="primary" onClick={getOtp}>
              Send Otp
            </Button>
          </div>
        </div>
        <Form onSubmit={verifyOtp} style={{ display: flag ? "block" : "none" }}>
          <Form.Group className="mb-3" controlId="formBasicOtp">
            <Form.Control
              type="otp"
              placeholder="Enter OTP"
              onChange={(e) => setOtp(e.target.value)}
            />
          </Form.Group>
          <div className="button-right">
            <Link to="/">
              <Button variant="secondary">Cancel</Button>
            </Link>
            &nbsp;
            <Button type="submit" variant="primary">
              Verify
            </Button>
          </div>
        </Form>
      </div>
    </>
  );
};

export default EmailSignUp;
