import { faCheckCircle, faExclamationCircle, faInfoCircle, faTag, faTimesCircle } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState } from 'react'
import { Button, Card } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { BottomSheet } from 'react-spring-bottom-sheet';
import { APICallStatus, PgOrderStatus } from '../../constants';
import { formatCurrency } from '../../constants/codeUtils';
import layout from '../../constants/layout';
import { theme } from '../../constants/theme';
import Dropdown from '../../elements/Dropdown';
import FooterCtaContainer from '../../elements/FooterCtaContainer';
import Input from '../../elements/Input/input'
import LoaderView from '../../elements/LoaderView';
import PhoneInput from '../../elements/PhoneInput';
import { setPaymentDetails, setSelectedPlan } from '../../redux/actions/app';
import { fetchAllRechargePlans, fetchReceiverProfile, handlePaymentPollingLogic, initiateMilindWalletTopup, initiateWalletTopup } from '../../redux/thunks/topup.thunk';
import ReceiverDetailsModal from '../modals/ReceiverDetailsModal';
import { styles } from './styles';
import QRCode from "react-qr-code";
import { ApiService } from '../../service/ApiService';
import { RotatingLines } from 'react-loader-spinner';

const TxnStatus = {
  NOT_STARTED: 'NOT_STARTED',
  PROCESSING: 'PROCESSING',
  SUCCESS: 'SUCCESS',
  PENDING: 'PENDING',
  FAILURE: 'FAILURE',
}

export default function AbroadPayment() {
  const [name, setName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [upiId, setUpiId] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const submitVpa = async () => {
    try {
      setIsLoading(true);
      const response = await initiateMilindWalletTopup({
        phoneNumber:"971505578965",
        planId:-3,
        senderName : name,
        senderPhoneNumber : phoneNumber,
      });
      if(response?.status === APICallStatus.SUCCESS) {
        dispatch(setPaymentDetails(response));
        dispatch(setSelectedPlan(-3));
        navigate('/abroad-checkout');
      }
      setIsLoading(false);
      setIsLoading(false);
    } catch (error) {
      setIsLoading(false);
    }
  }

  return (
    <>
    <div className="d-flex flex-column"  style={styles.container}>
      <p style={styles.title}>{`Payable amount`} - ₹ {`4,170`} + ₹ {`184.52`}(fees)</p>
      <p style={styles.title}>₹ {`4,354.52`}</p>
      <div className='mt-2'>
        <Input label={'Enter Name'} value={name} onChange={setName} inputContainerStyles={{marginTop: layout.window.toNormH(12)}}/>
        <Input label={'Enter Phone Number'} value={phoneNumber} onChange={setPhoneNumber} inputContainerStyles={{marginTop: layout.window.toNormH(12)}}/>
      </div>
    </div>
    <FooterCtaContainer 
      primaryAttributes={{
        title: 'Continue',
        onClick: submitVpa,
        isLoading: isLoading,
        isDisabled: !(name?.length > 0 && phoneNumber?.length > 5)
      }} 
    />
    </>
  )
}
