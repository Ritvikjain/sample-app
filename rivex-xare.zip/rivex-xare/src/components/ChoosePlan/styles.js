import layout from "../../constants/layout";
import { theme } from "../../constants/theme";

export const styles = {
  container: {
    padding: layout.window.toNormW(22),
    paddingBottom: layout.window.toNormH(140),
  },
  title: {
    fontSize: layout.window.toNormH(24),
  },
  infoCard: {
    borderRadius: layout.window.toNormW(12),
    boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px',
  },
  planCard: {
    borderRadius: layout.window.toNormW(12),
    boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px'
  },
  activePlanCard: {
    borderRadius: layout.window.toNormW(12),
    borderWidth: layout.window.toNormW(2),
    borderStyle: 'solid',
    borderColor: theme.COLOR.ThemePrimary,
    boxShadow: 'rgba(100, 100, 111, 0.2) 0px 7px 29px 0px'
  },
  planList: {
    marginTop: layout.window.toNormH(22)
  },
  planHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  planTitle: {
    fontSize: layout.window.toNormH(20),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.BlackPrimary,
  },
  horizontalLine: {
    width: '100%',
    height: layout.window.toNormH(1),
    backgroundColor: theme.COLOR.Grey200
  },
  planDescription: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimaryRegular,
    color: theme.COLOR.Black200,
  },
  planAmountContainer: {
    alignItems: 'center'
  },
  planAmount: {
    fontSize: layout.window.toNormH(26),
    fontFamily: theme.FONT.PrimaryBold,
  },
  feesText: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.ThemePrimary,
    alignSelf: 'center'
  },
  infoIcon: {
    fontSize: layout.window.toNormH(20),
    marginRight: layout.window.toNormW(8),
    marginTop: layout.window.toNormH(4)
  },
  infoTitle: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimaryRegular,
    color: theme.COLOR.YellowOrangeDark,
  },
  bottomSheet: {
    display: 'flex',
    flexDirection: 'column',
    height: layout.window.toNormH(500),
    paddingLeft: layout.window.toNormW(22),
    paddingRight: layout.window.toNormW(22),
    overflow: 'scroll',
    flex: 1,
  },
  orderSummaryTitle: {
    fontSize: layout.window.toNormH(20),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.BlackPrimary,
    textAlign: 'center'
  },
  rowContainer: {

  },
  amountData: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimaryBold,
    color: theme.COLOR.BlackPrimary,
  },
  amountDataMuted: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.BlackPrimary,
    textDecoration: 'line-through',
    marginRight: layout.window.toNormW(10),
  },
  amountDataSubTitle: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.BlackPrimary,
  },
  modalCta: {

  },
  noteContainer: {
    borderColor: theme.COLOR.YellowOrange,
    borderWidth: layout.window.toNormW(2),
    borderStyle: 'solid',
    borderRadius: layout.window.toNormW(6),
    padding: layout.window.toNormW(6)
  },
  conversionText: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.YellowOrangeDark,
  },
  closeCta: {
    textAlign: 'center',
  },
  closeCtaText: {
    fontSize: layout.window.toNormH(16),
    color: theme.COLOR.ThemePrimary,
    fontFamily: theme.FONT.PrimarySemiBold,
  },
  discountedBadge: {
    backgroundColor: theme.COLOR.SuccessGreen,
    // paddingVertical: layout.window.toNormH(4),
    // paddingHorizontal: layout.window.toNormW(12),
    borderRadius: layout.window.toNormW(22),
  },
  discountedText: {
    fontSize: layout.window.toNormH(16),
    fontFamily: theme.FONT.PrimarySemiBold,
    color: theme.COLOR.WhitePrimary,
    marginLeft: layout.window.toNormW(6),
  }
}