import { faExclamationCircle, faInfoCircle, faTag } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import React, { useEffect, useState } from 'react'
import { Card } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { BottomSheet } from 'react-spring-bottom-sheet';
import { APICallStatus } from '../../constants';
import { formatCurrency } from '../../constants/codeUtils';
import layout from '../../constants/layout';
import { theme } from '../../constants/theme';
import Dropdown from '../../elements/Dropdown';
import FooterCtaContainer from '../../elements/FooterCtaContainer';
import Input from '../../elements/Input/input'
import LoaderView from '../../elements/LoaderView';
import PhoneInput from '../../elements/PhoneInput';
import { setPaymentDetails, setSelectedPlan } from '../../redux/actions/app';
import { fetchAllRechargePlans, fetchReceiverProfile, initiateWalletTopup } from '../../redux/thunks/topup.thunk';
import ReceiverDetailsModal from '../modals/ReceiverDetailsModal';
import { styles } from './styles'

export default function ChoosePlan() {
  const [isLoading, setIsLoading] = useState(false);
  const [showLoader, setShowLoader] = useState(false);
  const [plans, setPlans] = useState([]);
  const [selectedPlan, setSelectedPlanTemp] = useState(null);
  const [showPlanDetails, setShowPlanDetails] = useState(false);
  const [loadCalled, setLoadCalled] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const onLoad = async () => {
    setShowLoader(true);
    const response = await fetchAllRechargePlans();
    if(response?.status === APICallStatus.SUCCESS) {
      setPlans(response?.planDetails);
      let discountedPlan = null;
      let recommendedPlan = null;
      response?.planDetails?.forEach(plan => {
        if (plan?.isDiscounted) {
          discountedPlan = plan;
        } else if (plan?.recommended) {
          recommendedPlan = plan;
        }
      });
      if(discountedPlan) {
        setSelectedPlanTemp(discountedPlan);
      } else {
        setSelectedPlanTemp(recommendedPlan);
      }
    }
    setShowLoader(false);
  }

  useEffect(()=>{
    if(!loadCalled) {
      onLoad();
      setLoadCalled(true);
    }
  }, [])

  const handleSubmit = async () => {
    try {
      setIsLoading(true);
      const response = await initiateWalletTopup({
        planId: selectedPlan?.planId,
      });
      if(response?.status === APICallStatus.SUCCESS) {
        dispatch(setPaymentDetails(response));
        dispatch(setSelectedPlan(selectedPlan));
        navigate('/checkout');
      }
      setIsLoading(false);
    } catch (error) {
      
    }
  }

  return (
    <>
    <div className="d-flex flex-column"  style={styles.container}>
      {/* <p style={styles.title}>Choose Plan</p> */}
      <div className='d-flex flex-column' style={styles.planList}>
        <Card className='p-3 mb-4 d-flex flex-row' style={styles.infoCard}>
          <FontAwesomeIcon icon={faInfoCircle} color={theme.COLOR.YellowOrangeDark} style={styles.infoIcon}/>
          <p className='mb-0' style={styles.infoTitle}>When you pay for a plan, the receiver will have the same amount credited in their wallet to Scan & Pay transactions for free.</p>
        </Card>

        {plans?.map(plan => <Card className='p-3 mb-4' style={selectedPlan?.planId === plan.planId ? styles.activePlanCard : styles.planCard} onClick={() => setSelectedPlanTemp(plan)}>
          <div className='d-flex justify-content-between mb-2' style={styles.planHeader}>
            <p className='mb-0' style={styles.planTitle}>{plan?.name}</p>
            {plan?.isDiscounted ? (
              <div className='d-flex justify-content-center align-items-center px-2' style={styles.discountedBadge}>
                <FontAwesomeIcon icon={faTag} color={theme.COLOR.WhitePrimary}/>
                <p className='mb-0' style={styles.discountedText}>
                  {`${plan?.discountDetails?.discountCoupon} applied`}
                </p>
              </div>
            ) : null}
          </div>
          <div style={styles.horizontalLine}></div>
          <p className='mt-2' style={styles.planDescription}>{plan?.description}</p>
          <div className='d-flex flex-row justify-content-between align-items-end' style={styles.planAmountContainer}>
            <p className='mb-0' style={styles.planAmount}>₹ {formatCurrency(plan?.packAmountInr)}</p>
            {plan?.isDiscounted ? 
              <p className='d-flex align-items-end mb-0' style={styles.feesText}>Buy @  
              <p className='mb-0 mx-1' style={{textDecoration: 'line-through',}}>$ {plan?.fees} </p>
              $ {plan?.discountDetails?.discountedFees}</p> : 
              <p className='mb-0' style={styles.feesText}>Buy @ $ {plan?.fees}</p>}
          </div>
        </Card>)}
      </div>
    </div>
    {showLoader ? <LoaderView /> : null}
    <FooterCtaContainer 
      primaryAttributes={{
        title: 'Continue',
        onClick: () => setShowPlanDetails(true),
        isLoading: isLoading,
      }}
    />
    <BottomSheet open={showPlanDetails}>
      <div style={styles.bottomSheet}>
        <p style={styles.orderSummaryTitle}>Order summary</p>
        <div className='d-flex justify-content-between' style={styles.rowContainer}>
          <p style={styles.amountData}>Amount (in USD)</p>
          {/* <p style={styles.amountData}>$ {formatCurrency(selectedPlan?.packAmountInForeignCurrency)}</p> */}
          <div className='d-flex flex-column justify-content-center align-items-end'>
            <p className='m-0' style={styles.amountData}>$ {formatCurrency(selectedPlan?.packAmountInForeignCurrency)}</p>
            <p style={styles.amountDataSubTitle}>( ₹ {formatCurrency(selectedPlan?.packAmountInr)} )</p>
          </div>
        </div>
        <div className='d-flex justify-content-between' style={styles.rowContainer}>
          <p style={styles.amountData}>Convinience fees</p>
          {selectedPlan?.isDiscounted ? <span className='d-flex'>
            <p style={styles.amountDataMuted}>$ {formatCurrency(selectedPlan?.fees)}</p>
            <p style={styles.amountData}>$ {formatCurrency(selectedPlan?.discountDetails?.discountedFees)}</p>
          </span> : <p style={styles.amountData}>$ {formatCurrency(selectedPlan?.fees)}</p>}
        </div>
        <div style={styles.horizontalLine}></div>
        <div className='d-flex justify-content-between mt-3' style={styles.rowContainer}>
          <p style={styles.amountData}>Total payable amount</p>
          <div className='d-flex flex-column justify-content-center align-items-end'>
            <p className='m-0' style={styles.amountData}>$ {formatCurrency(selectedPlan?.totalPayableAmount)}</p>
            <p style={styles.amountDataSubTitle}>( ₹ {formatCurrency(selectedPlan?.totalPayableAmountInr)} )</p>
          </div>
        </div>
        <div className='d-flex px-2 align-items-center mt-1' style={styles.noteContainer}>
          <FontAwesomeIcon icon={faExclamationCircle} style={{color: theme.COLOR.YellowOrangeDark}}/>
          <p className='m-0 px-2' style={styles.conversionText}>{selectedPlan?.conversionText}</p>
        </div>
      </div>
        <FooterCtaContainer 
          hidePoweredWidget
          aboveDescriptionText={'*Amount will be charged in INR'}
          primaryAttributes={{
            title: 'Pay',
            onClick: handleSubmit,
            isLoading: isLoading,
          }}
          bottomDescription={<div className='pt-3' style={styles.closeCta} onClick={() => setShowPlanDetails(false)}>
            <p className='mb-0' style={styles.closeCtaText}>Close</p>
          </div>}
        />
    </BottomSheet>
    </>
  )
}
