import { Container, Row, Col } from "react-bootstrap";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./components/Home";
import Login from "./components/Login";
import ProtectedRoute from "./components/ProtectedRoute";
import Header from "./components/Header";
import EmailSignUp from "./components/EmailSignUp";
import AuthVerification from "./components/AuthVerification";
import VerifyReceiver from "./components/VerifyReceiver";
import ChoosePlan from "./components/ChoosePlan";
import Checkout from "./components/Checkout";
import IndiaPayment from "./components/IndiaPayment";
import AbroadPayment from "./components/AbroadPayment";
import AbroadCheckout from "./components/AbroadCheckout";
import SelfTopup from "./components/SelfTopup";

function App() {

  return (
    <Routes>
      <Route
        path="/abroad-checkout"
        element={
          // <ProtectedRoute>
          <>
            <Header
              title={'Paying to milind'}
              showBackButton
            />
            <AbroadCheckout />
          </>
          // </ProtectedRoute>
        }
      />
      <Route
        path="/abroad-payment"
        element={
          // <ProtectedRoute>
          <>
            <Header
              title={'Paying to Milind'}
            />
            <AbroadPayment />
          </>
          // </ProtectedRoute>
        }
      />
      <Route
        path="/india-payment"
        element={
          // <ProtectedRoute>
          <>
            <Header
              title={'Paying to Milind'}
            />
            <IndiaPayment />
          </>
          // </ProtectedRoute>
        }
      />
      <Route
        path="/self-topup"
        element={
          // <ProtectedRoute>
          <>
            <Header
              title={'Self Topup'}
            />
            <SelfTopup />
          </>
          // </ProtectedRoute>
        }
      />
      <Route
        path="/verifyReceiver"
        element={
          <ProtectedRoute>
            <Header
              title={'Verify receiver'}
            />
            <VerifyReceiver />
          </ProtectedRoute>
        }
      />
      <Route
        path="/choosePlan"
        element={
          <ProtectedRoute>
            <Header
              title={'Choose plan'}
              showBackButton
            />
            <ChoosePlan />
          </ProtectedRoute>
        }
      />
      <Route
        path="/checkout"
        element={
          <ProtectedRoute>
            <Header
              title={'Checkout'}
              showBackButton
            />
            <Checkout />
          </ProtectedRoute>
        }
      />
      <Route path="/" element={<AuthVerification />} />
      <Route path="/emailsignup" element={<EmailSignUp />} />
    </Routes>
  );
}

export default App;
