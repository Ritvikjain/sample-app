import React from 'react'
import { BallTriangle } from 'react-loader-spinner'
import layout from '../../constants/layout'

const styles = {
  loaderContainer: {
    position: 'absolute',
    width: '100%',
    height: '100vh',
    display: 'flex', 
    flex: 1,
    justifyContent: 'center', 
    alignItems: 'center',
  }
}
export default function LoaderView() {
  return (
    <div style={styles.loaderContainer}>
      <BallTriangle
        height={120}
        width={layout.window.toNormW(100)}
        radius={layout.window.toNormW(6)}
        color="#1981f9"
        ariaLabel="ball-triangle-loading"
        wrapperClass={{}}
        wrapperStyle=""
        visible={true}
      />
    </div>
  )
}
