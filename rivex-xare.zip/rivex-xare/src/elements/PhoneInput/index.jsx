import React, { useEffect, useState } from "react";
import {
  Button,
  Dropdown,
  DropdownButton,
  FloatingLabel,
  Form,
  InputGroup,
} from "react-bootstrap";
import { countriesData } from "../../constants/countries";
// import Dropdown from "../Dropdown";
import { BottomSheet } from 'react-spring-bottom-sheet'
import 'react-spring-bottom-sheet/dist/style.css'
import { theme } from "../../constants/theme";
import Input from "../Input/input";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";
import layout from "../../constants/layout";

const styles = {
  inputContainer: {
    width: "100%",
  },
  inputTitle: {
    fontSize: layout.window.toNormH(16),
  },
  countryFlag: {
    width: layout.window.toNormW(25),
    height: layout.window.toNormH(20),
    marginRight: layout.window.toNormW(12)
  },
  bottomSheet: {
    width: '100vw',
    position: 'absolute',
    bottom: 0,
    backgroundColor: theme.COLOR.WhitePrimary,
    height: layout.window.toNormH(500),
    paddingTop: layout.window.toNormW(12),
    paddingLeft: layout.window.toNormW(22),
    paddingRight: layout.window.toNormW(22),
    borderRadius: '16px 16px 0 0',
  },
  bottomSheetTitle: {
    fontSize: layout.window.toNormH(20),
  },
  bottomSheetSubtitle: {
    fontSize: layout.window.toNormH(16),
  },
  horizontalLine: {
    width: '100%',
    height: layout.window.toNormH(2),
    backgroundColor: theme.COLOR.Grey
  },
  listContainer: {
    width: '100%',
    maxHeight: layout.window.toNormH(320),
    marginTop: layout.window.toNormH(22),
    overflow: 'scroll',
  },
  optionItem: {
    marginBottom: layout.window.toNormH(12),
    width: '100%',
  },
  dropdownCta: {
    width: '100px',
    backgroundColor: theme.COLOR.WhitePrimary,
    borderWidth: layout.window.toNormW(1),
    borderStyle: 'solid',
    borderColor: theme.COLOR.LightGrey,
    marginRight: layout.window.toNormW(12),
    borderRadius: layout.window.toNormW(6),
    justifyContent: 'center',
    alignItems: 'center',
  },
  backdrop: {
    position: 'fixed',
    width: '100vw',
    height: '100vh',
    top: 0,
    left: 0,
    bottom: 0,
    zIndex: 10,
    backgroundColor: '#00000050'
  }
};

export default function PhoneInput({
  label,
  placeholder,
  value,
  onChange,
  selectedCountryCode,
  onChangeCountryCode,
}) {
  const [dropdownOptionsVisible, setDropdownOptionsVisible] = useState();
  const [searchInput, setSearchInput] = useState('');
  const [optionsList, setOptionsList] = useState(countriesData);

  useEffect(() => {
    if (!selectedCountryCode) {
      onChangeCountryCode(countriesData[0]);
    }
  });

  const handleSearchChange = (value) => {
    setSearchInput(value);
    if(!value || value?.length === 0) {
      setOptionsList(countriesData);
    }
    let filteredList = [];
    countriesData.forEach(country => {
      if(country?.name?.toLowerCase()?.indexOf(value?.toLowerCase()) > -1 || country?.dial_code?.toLowerCase()?.indexOf(value?.toLowerCase()) > -1) {
        filteredList.push(country);
      }
    })
    setOptionsList(filteredList);
  }

  return (
    <div style={styles.inputContainer}>
      <Form.Group>
        <Form.Label>{label}</Form.Label>
        <div className="d-flex">
          <div className="d-flex" onClick={() => setDropdownOptionsVisible(true)} style={styles.dropdownCta}>
            <img src={`https://flagcdn.com/48x36/${selectedCountryCode?.code?.toLowerCase()}.png`} style={styles.countryFlag}></img>
            <FontAwesomeIcon icon={faChevronDown} />
          </div>
          <Input 
            className="d-flex ml-4"
            type="text"
            placeholder={placeholder ? placeholder : ""}
            value={value}
            onChange={onChange}
          />
        </div>
      </Form.Group>
      {dropdownOptionsVisible ? <div style={styles.backdrop}><div style={styles.bottomSheet}>
        <p className="m-0" style={styles.bottomSheetTitle}>Country code</p>
        <p style={styles.bottomSheetSubtitle}>Please select receiver's country code</p>
        <div style={styles.horizontalLine}></div>
        <Input 
          placeholder={'Search'}
          value={searchInput}
          onChange={handleSearchChange}
          inputContainerStyles={{marginTop: layout.window.toNormH(22)}}
        />
        <div style={styles.listContainer}>
          {optionsList?.map(country => <div className="d-flex flex-row" style={styles.optionItem} onClick={() => {
            setDropdownOptionsVisible(false);
            onChangeCountryCode(country);
          }}>
            <img src={`https://flagcdn.com/48x36/${country?.code?.toLowerCase()}.png`} style={styles.countryFlag}></img>
            <p className="m-0">{country?.name} ({country?.dial_code})</p>
          </div>)}
        </div>
      </div></div> : null}
    </div>
  );
}
