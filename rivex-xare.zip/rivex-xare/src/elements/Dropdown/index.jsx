import React from 'react'
import { Form } from 'react-bootstrap'

export default function Dropdown({
  label,
  value,
  options,
  onChange,
}) {
  return (
    <Form.Group>
      {label ? <Form.Label>{label}</Form.Label> : null}
      <Form.Select aria-label="Default select example" style={{height: '50px'}} onChange={(e) => {
        onChange(e.target.value)
      }}>
        {options?.map(option => <option value={option?.value}>
          <img src={`https://flagcdn.com/48x36/${option?.code?.toLowerCase()}.png`}></img>{option.name}
        </option>)}
      </Form.Select>
    </Form.Group>
  )
}
